package com.example.verygoodcore.chat_bot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
