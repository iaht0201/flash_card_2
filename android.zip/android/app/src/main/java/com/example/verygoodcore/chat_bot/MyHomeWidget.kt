package com.example.verygoodcore.chat_bot

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import es.antonborri.home_widget.HomeWidgetPlugin

/**
 * Implementation of App Widget functionality.
 */
class MyHomeWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        // There may be multiple widgets active, so update all of them
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onEnabled(context: Context) {
        // Enter relevant functionality for when the first widget is created
    }

    override fun onDisabled(context: Context) {
        // Enter relevant functionality for when the last widget is disabled
    }
}

internal fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
    val widgetData = HomeWidgetPlugin.getData(context)

    val word = widgetData.getString("word", "No word")
    val meaning = widgetData.getString("meaning", "No meaning")

    val views = RemoteViews(context.packageName, R.layout.my_home_widget).apply {
        setTextViewText(R.id.word_id, word ?: "No word")
        setTextViewText(R.id.meaning_id, meaning ?: "No meaning")
    }

    appWidgetManager.updateAppWidget(appWidgetId, views)
}